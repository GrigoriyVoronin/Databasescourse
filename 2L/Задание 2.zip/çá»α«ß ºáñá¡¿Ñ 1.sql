UPDATE catalogs 
SET 
    name = 'empty'
WHERE
    name IS NULL OR name = '';