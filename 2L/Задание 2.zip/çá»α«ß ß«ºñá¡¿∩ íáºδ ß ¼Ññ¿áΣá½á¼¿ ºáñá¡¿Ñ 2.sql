CREATE DATABASE mediastore;
USE mediastore;

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(30)
)  COMMENT='Пользователи';

CREATE TABLE key_words (
    id SERIAL PRIMARY KEY,
    word VARCHAR(30)
)  COMMENT='Ключевые слова';

CREATE TABLE media_files (
    id SERIAL PRIMARY KEY,
    path VARCHAR(255) COMMENT 'Путь к файлу',
    name VARCHAR(255) COMMENT 'Имя файла',
    description VARCHAR(255) COMMENT 'Описание файла',
    key_words_id INT UNSIGNED,
    user_id INT UNSIGNED
)  COMMENT='Медиафайлы';
